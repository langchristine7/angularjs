var ingoControllers = angular.module('ingoControllers', []);
/*
celui du prof
ingoControllers.controller('ingoListCtrl', ['$scope', '$http', 'ingoFactory', 'ingoDataFactory', function($scope, $http, ingoFactory, ingoDataFactory){
*/
ingoControllers.controller('ingoListCtrl', ['$scope', 'ingoFactory', 'ingoDataFactory', function($scope, ingoFactory, ingoDataFactory){
  
  $scope.aocs = ingoFactory.aocsTransformed('--');
  $scope.committees = ingoFactory.committees;
  $scope.geoReps = ingoFactory.geoReps;
  
  if(!ingoDataFactory.ingos){
    ingoDataFactory.getIngos().then(//promise
      function(data){//success
        $scope.ingos = data;
      }
    );
  }else{
        $scope.ingos = ingoDataFactory.ingos;
  }
  
}]);


ingoControllers.controller('ingoDetailCtrl', ['$scope', '$routeParams', 'ingoDataFactory', function($scope, $routeParams, ingoDataFactory){
  
  var id = parseInt($routeParams.id);
  $scope.id = id;
        
  if (!ingoDataFactory.ingos) { // ingos jamais chargées dans le factory
      ingoDataFactory.getIngos().then(
        function(data) {
          $scope.ngo = ingoDataFactory.getIngo(id);
      }
    );
  } else {
      $scope.ngo = ingoDataFactory.getIngo(id);
  }

}]);

/*ingoControllers.controller('ngoListCtrl', ['$scope', 'ingoFactory', function($scope, ingoFactory){
  
  var id = parseInt($routeParams.id);
  $scope.id = id;
  switch(id){
    case 'country':
      $scocpe.ngos.list = ingoFactory.geoReps;
      break;
    case 'committee':
      $scocpe.ngos.list = ingoFactory.committees;
      break;
    case 'area of competence':
      $scocpe.ngos.list = ingoFactory.aocsTransformed('  ');
      break;
  }
  
}]);*/


ingoControllers.controller('ingoSignInCtrl', ['$scope', '$routeParams', function($scope, $routeParams){

}]);